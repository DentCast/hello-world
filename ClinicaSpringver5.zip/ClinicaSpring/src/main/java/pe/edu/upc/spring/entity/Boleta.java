package pe.edu.upc.spring.entity;


import java.io.Serializable;

import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;




@Entity
@Table(name = "boleta")
public class Boleta implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idboleta;
	
	@NotNull
	@Past(message="No puedes seleccionar un dia que todavia NO existe")
	@Temporal(TemporalType.DATE)
	@Column(name="fecha")
	@DateTimeFormat(pattern="dd-MM-yyyy")
	private Date fecha;
	
	
	@NotEmpty(message = "No puede estar vacÃ­o")
	@NotBlank(message = "No puede estar en blanco")
	@Column(name="medioPago", nullable=false,length=20)
    private String mediopago;
	
	@ManyToOne
	@JoinColumn(name = "idservicio", nullable = false)
	private Servicio idservicio;
	
	@ManyToOne
	@JoinColumn(name = "idreserva", nullable = false)
	private Reserva idreserva;
	
	public Boleta(int idboleta, Date fecha, String  mediopago, Servicio idservicio, Reserva idreserva) {
		super();
		this.idboleta = idboleta;
		this.fecha = fecha;
		this.mediopago = mediopago;
		this.idreserva = idreserva;
		
	}
	
	public Boleta() {
		super();
	}

	@PrePersist
	public void prePersist() {
		fecha = new Date();
	}

	
	public int getIdboleta() {
		return idboleta;
	}

	public void setIdboleta(int idboleta) {
		this.idboleta = idboleta;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getMediopago() {
		return mediopago;
	}

	public void setMediopago(String mediopago) {
		this.mediopago = mediopago;
	}

	public Servicio getIdservicio() {
		return idservicio;
	}

	public void setIdservicio(Servicio idservicio) {
		this.idservicio = idservicio;
	}

	public Reserva getIdreserva() {
		return idreserva;
	}

	public void setIdreserva(Reserva idreserva) {
		this.idreserva = idreserva;
	}
	

	
}