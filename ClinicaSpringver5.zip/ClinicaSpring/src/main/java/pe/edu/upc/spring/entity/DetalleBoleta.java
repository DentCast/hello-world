package pe.edu.upc.spring.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import pe.edu.upc.spring.entity.DetalleBoleta;


@Entity
@Table(name = "detalleboleta")
public class DetalleBoleta {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int iddetalleboleta;
	
	@Column(name="cantidadservicios",length =60,nullable=false)
	private int cantidadservicios;
	
    @ManyToOne
    @JoinColumn(name = "idservicio", nullable = false)
    private Servicio idservicio;

    @ManyToOne
    @JoinColumn(name = "idpromocion", nullable = false)
     private Promocion idPromocion;
    
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "detalleboleta_id")
	private List<Boleta> boleta;
    
    
    public DetalleBoleta(int iddetalleboleta, int cantidadservicios, List<Boleta> boleta, Servicio idservicio,Promocion idPromocion ) {
		super();
		this.iddetalleboleta = iddetalleboleta;
		this.cantidadservicios = cantidadservicios;
		this.boleta = boleta;
		this.idservicio = idservicio;
		this.idPromocion = idPromocion;
	}
	public DetalleBoleta() {
		this.boleta = new ArrayList<>();
	}

   
    public int getIddetalleboleta() {
		return iddetalleboleta;
	}


	public void setIddetalleboleta(int iddetalleboleta) {
		this.iddetalleboleta = iddetalleboleta;
	}


	public int getCantidadservicios() {
		return cantidadservicios;
	}


	public void setCantidadservicios(int cantidadservicios) {
		this.cantidadservicios = cantidadservicios;
	}


	public Servicio getIdservicio() {
		return idservicio;
	}


	public void setIdservicio(Servicio idservicio) {
		this.idservicio = idservicio;
	}


	public Promocion getIdPromocion() {
		return idPromocion;
	}


	public void setIdPromocion(Promocion idPromocion) {
		this.idPromocion = idPromocion;
	}


	public List<Boleta> getBoleta() {
		return boleta;
	}


	public void setBoleta(List<Boleta> boleta) {
		this.boleta = boleta;
	}
	
	public void addBoletaDetalle(Boleta item) {
		this.boleta.add(item);
	}

	public Double getTotal() {

		return boleta.stream().collect(Collectors.summingDouble(Boleta::calculateAmount));
	}

	public Double calculateAmount() {
		
		return cantidadservicios*idservicio.getCosto();
	}
    
}
