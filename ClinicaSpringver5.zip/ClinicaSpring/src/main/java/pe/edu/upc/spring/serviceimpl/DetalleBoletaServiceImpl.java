package pe.edu.upc.spring.serviceimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.entity.DetalleBoleta;

import pe.edu.upc.spring.repository.IDetalleBoletaDAO;
import pe.edu.upc.spring.service.IDetalleBoletaService;

@Service
public class DetalleBoletaServiceImpl implements IDetalleBoletaService {

	@Autowired
	private IDetalleBoletaDAO cDetalleBoleta;
	

	@Override
	public boolean insertar(DetalleBoleta detalleboleta) {
		DetalleBoleta objDetalleBoleta = cDetalleBoleta.save(detalleboleta);
		if (objDetalleBoleta == null){
			return false;
		}else{
			return true;
		}		
	}

	@Override
	@Transactional
	public boolean modificar(DetalleBoleta detalleboleta) {
		boolean flag=false;
		try {
			cDetalleBoleta.save(detalleboleta);
			flag=true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return flag;
	}

	@Override
	@Transactional
	public void eliminar(int idDetalleBoleta) {
		cDetalleBoleta.delete(idDetalleBoleta);
		
	}

	@Override
	@Transactional(readOnly=true)
	public DetalleBoleta listarId(int idDetalleBoleta) {
		return cDetalleBoleta.findOne(idDetalleBoleta);
	}

	@Override
	@Transactional(readOnly=true)
	public List<DetalleBoleta> listar() {
		return cDetalleBoleta.findAll();
	}
	
	@Override
	public List<DetalleBoleta> findByDetalleBoleta(String nameDetalleBoleta) {
		return cDetalleBoleta.findByNameDetalleBoleta(nameDetalleBoleta);
	}
}
    
