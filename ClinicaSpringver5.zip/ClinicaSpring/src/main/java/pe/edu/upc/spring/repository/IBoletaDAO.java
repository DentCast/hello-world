package pe.edu.upc.spring.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import pe.edu.upc.spring.entity.Boleta;

@Repository
public interface IBoletaDAO extends JpaRepository <Boleta,Integer> {

	@Query("select v from Boleta v join fetch v.cliente p join fetch v.detallecomprobante bd join fetch bd.producto join fetch v.empleado e  join fetch v.mediopago mp join fetch v.sucursal su where v.idboleta=?1")
	Optional<Boleta> fetchByVoucherIdWithPatientWhithVoucherDetailWithMedicine(int id);	
}