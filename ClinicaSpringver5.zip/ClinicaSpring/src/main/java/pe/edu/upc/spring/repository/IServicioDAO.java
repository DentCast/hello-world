package pe.edu.upc.spring.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import pe.edu.upc.spring.entity.Servicio;

@Repository
public interface IServicioDAO extends JpaRepository<Servicio,Integer>{
	
	List<Servicio> findByNameServicio(String nameServicio);

}
