package pe.edu.upc.spring.controller;

public class DetalleBoletaController {

}
