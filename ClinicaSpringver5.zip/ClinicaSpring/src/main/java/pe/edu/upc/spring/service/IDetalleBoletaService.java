package pe.edu.upc.spring.service;

import java.util.List;

import pe.edu.upc.spring.entity.DetalleBoleta;

public interface IDetalleBoletaService {

public boolean insertar(DetalleBoleta detalleboleta);
	
	public boolean modificar(DetalleBoleta detalleboleta);
	
	public void eliminar(int idDetalleBoleta);
	
	
	public DetalleBoleta listarId(int idDetalleBoleta); //
	
	public List<DetalleBoleta> listar();
	
	List<DetalleBoleta> findByDetalleBoleta(String nameDetalleBoleta);
	
}
